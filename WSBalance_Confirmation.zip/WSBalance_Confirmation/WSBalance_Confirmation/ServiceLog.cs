﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WSBalance_Confirmation
{
    class ServiceLog
    {
        public static void writeErrorLog(Exception ex)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "Logfile.txt", true);
                sw.WriteLine(DateTime.Now.ToString() + ":  " + ex.Source.ToString() + ";" + ex.Message.ToString());
                sw.Flush();
                sw.Close();
            }
            catch (Exception e)
            {

            }

        }

        public static void writeLog(string message)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "Logfile.txt", true);
                sw.WriteLine(DateTime.Now.ToString() + ":  " + message.ToString());
                sw.Flush();
                sw.Close();
            }
            catch (Exception e)
            {

            }
        }
    }
}
