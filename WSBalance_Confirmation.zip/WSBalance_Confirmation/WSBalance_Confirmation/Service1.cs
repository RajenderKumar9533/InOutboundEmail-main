﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WSBalance_Confirmation
{
    public partial class Service1 : ServiceBase
    {
        public static System.Timers.Timer Timer1;
        public Service1()
        {
          
            InitializeComponent();
            Timer1 = new System.Timers.Timer();
            double inter = (double)getNextInterval();
            Timer1.Interval = inter;
            Timer1.Elapsed += new ElapsedEventHandler(ServiceTimer_Tick);
        }

        private double getNextInterval()
        {
            String timeString = "3:00 PM";
            DateTime t = DateTime.Parse(timeString);
            TimeSpan ts = new TimeSpan();

            ts = t - System.DateTime.Now;

            if (ts.TotalMilliseconds < 0)
            {
                ts = t.AddDays(1) - System.DateTime.Now;
            }
            return ts.TotalMilliseconds;
        }

        private void setTimer()
        {
            try
            {
                double inter = (double)getNextInterval();
                Timer1.Interval = inter;
                Timer1.Start();
            }
            catch (Exception e)
            {
                ServiceLog.writeErrorLog(e);
            }
        }


        private void ServiceTimer_Tick(Object source, System.Timers.ElapsedEventArgs e)
        {
            SendEmail();
            SendMSMEMail();
            Timer1.Stop();
            System.Threading.Thread.Sleep(1000000);
            setTimer();
        }

        public static void SendEmail()
        {
            var context = new ServiceVMSEntities();
            try
            {
                IQueryable<HTV_Vendor> vendorList = null;
                ServiceLog.writeLog("-----------------send email method start-----------------------");
                vendorList = from v in context.HTV_Vendor
                             where ((!v.vendorId.Contains("DUM") || !v.vendorCode.Contains("DUM")) &&  v.vendorStatus == null && (v.CSTNo == "Registered"  || v.CSTNo == null))
                             select v;

                

                DateTime firstquaterdate = new DateTime(2023,07,10);
                DateTime secquaterdate = new DateTime(2023, 10, 10);
                DateTime thirdquaterdate = new DateTime(2023, 1, 10);
                DateTime fourquaterdate = new DateTime(2023, 04, 10);
                var c = vendorList.Count();
                //DateTime firstquaterdate = new DateTime(2023, 06, 21);
                //DateTime secquaterdate = new DateTime(2023, 06, 17);
                //DateTime thirdquaterdate = new DateTime(2023, 06, 18);
                //DateTime fourquaterdate = new DateTime(2023, 06, 19);
                string actualdate = "";
                bool ismailsend = false;
                if(DateTime.Now.Date == firstquaterdate.Date && DateTime.Now.Month == firstquaterdate.Month)
                {
                    actualdate = "30th June";
                    ismailsend = true;
                }
                else if(DateTime.Now.Date == secquaterdate.Date && DateTime.Now.Month == secquaterdate.Month)
                {
                    actualdate = "30th September";
                    ismailsend = true;
                }
                else if(DateTime.Now.Date == thirdquaterdate.Date && DateTime.Now.Month == thirdquaterdate.Month)
                {
                    actualdate = "31st December";
                    ismailsend = true;
                }
                else if(DateTime.Now.Date == fourquaterdate.Date && DateTime.Now.Month == fourquaterdate.Month)
                {
                    actualdate = "31st March";
                    ismailsend = true;
                }
                if (ismailsend == true)
                {
                    foreach (var v in vendorList)
                    {
                        MailMessage mail = new MailMessage();
                        mail.To.Add(v.vendorEmail.ToString());
                        ServiceLog.writeLog("Vendor mail: " + v.vendorEmail.ToString() + "  " +DateTime.Now.ToString());
                        mail.CC.Add("facilities@harbingergroup.com");
                        mail.CC.Add("accountspayable@Harbingergroup.com");
                       // mail.CC.Add("kartikaluhar@yopmail.com");

                        string email = "htvvms@harbingergroup.com";
                        mail.From = new MailAddress(email);

                        DirectoryInfo dir = new DirectoryInfo(@"C:\HTV-VMSDocs\webservice\");
                        foreach (FileInfo file2 in dir.GetFiles("*.*"))
                        {
                            if (file2.Exists)
                            {
                                mail.Attachments.Add(new Attachment(file2.FullName));
                            }
                        }
                        string Body = "Dear Valued Partner, <br><br>Greetings from Harbinger Group!!<br><br>" +
                                      "As per the company guidelines, we will be closing the books of accounts at the end of every quarter  " +
                                       actualdate.ToString() + "  For the quarterly reconciliation of the balances, " +
                                      "we request you to please send the ledger on or before 10th day from the end of the quarter." +
                                      "<br><br>Regards," + "<br><b>Team Procurement - Harbinger</b>" +
                                      "<br><br><font size=\"2\" color=\"red\"> <i> Note : This is a system generated email. Please do not reply to this email.</i></font>";
                        

                        mail.Subject = "Harbinger Group - Quarterly Balance Confirmation"; 
                        mail.Body = Body;
                        mail.Priority = MailPriority.High;
                        mail.IsBodyHtml = true;
                        string username = "htvvms@harbingergroup.com";
                        string password = "fdbykkgbxsfvwwtx";
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = "smtp.office365.com";
                        smtp.Port = 587;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = new System.Net.NetworkCredential(username, password); // Enter seders User name and password                                      
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                        ServiceLog.writeLog("Send mail: balance confirmation mail" + actualdate.ToString());
                    }
                }

            }
            catch
            {

            }

        }

        public static void SendMSMEMail()
        {
            var context = new ServiceVMSEntities();
            try
            {
                IQueryable<HTV_Vendor> vendorList = null;
                ServiceLog.writeLog("-----------------send email method start-----------------------");
                vendorList = from v in context.HTV_Vendor
                             where ((!v.vendorId.Contains("DUM") || !v.vendorCode.Contains("DUM")) && v.vendorStatus == null && (v.CSTNo == "Registered" || v.CSTNo == null))
                             select v;



                //DateTime firstquaterdate = new DateTime(2023,06,22);
                //DateTime secquaterdate = new DateTime(2023, 08, 31);
                var c = vendorList.Count();
                DateTime firstquaterdate = new DateTime(2023, 03,31);
                DateTime secquaterdate = new DateTime(2023, 09, 30);
                
                string actualdate = "";
                bool ismailsend = false;
                if (DateTime.Now.Date == firstquaterdate.Date && DateTime.Now.Month == firstquaterdate.Month)
                {
                    
                    ismailsend = true;
                }
                else if (DateTime.Now.Date == secquaterdate.Date && DateTime.Now.Month == secquaterdate.Month)
                {
                    
                    ismailsend = true;
                }
               
                if (ismailsend == true)
                {
                    foreach (var v in vendorList)
                    {
                        MailMessage mail = new MailMessage();
                        mail.To.Add(v.vendorEmail.ToString());
                        ServiceLog.writeLog("Vendor MSME mail: " + v.vendorEmail.ToString() + "  " + DateTime.Now.ToString());
                        //mail.CC.Add("facilities@harbingergroup.com");
                        mail.CC.Add("accountspayable@Harbingergroup.com");
                        mail.CC.Add("akshay.nair@harbingergroup.com");
                        mail.CC.Add("ashvin.mutthal@harbingergroup.com");
                        //mail.CC.Add("kartikaluhar@yopmail.com");

                        string email = "htvvms@harbingergroup.com";
                        mail.From = new MailAddress(email);


                        string Body = "<b>Dear Partners,</b>" +
                                      "<br><br><b>Greetings from Harbinger Group...!!</b>" +
                                      "<br><br>As you may be aware, " +
                                     "the Government of India has enacted the Order" +
                                     "Called the Specified Companies (Furnishing of Information about payment to " +
                                     "Micro and Small Enterprises Suppliers) Order, 2019 and the Government of India" +
                                     "has made it compulsory for all Companies to file the “MSME Form I and Half yearly Return”. " +
                                     "<br><br>In order to enable us to file such return we request you, to confirm whether your organization is registered under Micro Small" +
                                     " and Medium Enterprises Development Act, 2006.If your organization is registered under the Act, please provide us the following information through email " +
                                     "and also send us the scanned copy of your MSME Registration Certificate on accountspayable@Harbingergroup.com & Facilities@harbingergroup.com" +
                                     "<br><ol><li>	Name of Supplier:</li><li>	Category of MSME (Micro/Small/Medium):</li><li>	PAN No. of Supplier:</li></ol>" +
                                     "<br><br>Regards,<br>Accounts - Harbinger" +
                                     "<br><br><font size=\"2\" color=\"red\"> <i> Note : This is a system generated email. Please do not reply to this email.</i></font>";



                        mail.Subject = "Information on MSME Registration";
                        mail.Body = Body;
                        mail.Priority = MailPriority.High;
                        mail.IsBodyHtml = true;
                        string username = "htvvms@harbingergroup.com";
                        string password = "fdbykkgbxsfvwwtx";
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = "smtp.office365.com";
                        smtp.Port = 587;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = new System.Net.NetworkCredential(username, password); // Enter seders User name and password                                      
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                        ServiceLog.writeLog("Send mail: balance confirmation mail" + actualdate.ToString());
                    }
                }

            }
            catch
            {

            }
        }

        protected override void OnStart(string[] args)
        {
            ServiceLog.writeLog("Started Service HTVVMS Balance Confirmation email service");
            Timer1.AutoReset = true;
            Timer1.Enabled = true;
        }

        protected override void OnStop()
        {
            Timer1.AutoReset = false;
            Timer1.Enabled = false;
        }
    }
}
